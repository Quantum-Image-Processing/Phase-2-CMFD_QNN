# BusterNet Training Workspace

This is a portable training workspace for the BusterNet model for image forgery detection.

## Overview

This workspace contains all the code necessary to run:
- **Experiment 0**: Overfit sanity check on 8 images
- **Experiment 1**: Fine-tuning the converted BusterNet checkpoint
- **Experiment 2**: Stage-wise training (following the original BusterNet paper)
- Inference and evaluation scripts

## System Requirements

- GPU with CUDA support (for training)
- Python 3.8+
- PyTorch 1.9+
- Sufficient disk space for dataset and checkpoints

## Installation

1. Copy this entire folder to your GPU-enabled machine
2. Install the required Python packages:
   ```bash
   pip install -r requirements.txt
   ```
3. Place your dataset in the expected location (see Dataset Setup below)

## Dataset Setup

The code expects the dataset to be organized as follows:

```
coco_subset/
├── images/                   # Original images
├── images_forged/            # Forged images
├── masks/                    # All masks
├── masks_3class/             # 3-class masks (0: authentic, 1: source, 2: target)
├── masks_binary/             # Binary masks (0: authentic, 1: forged)
├── forgery_manifest_with_masks_train.csv   # Training manifest
├── forgery_manifest_with_masks_val.csv     # Validation manifest
├── forgery_manifest_with_masks_test.csv    # Test manifest
└── forgery_manifest_with_masks.csv         # Full manifest (used if train/val split not specified)
```

The CSV files should contain columns including:
- `image_id`, `file_name`: Original image filename
- `forged_file_name`: Forged image filename
- `mc_file_name`: 3-class mask filename
- `mm_file_name`: Binary mask filename
- And other metadata columns

## Experiments

### Experiment 0: Overfit Sanity Check
Verifies that the training pipeline can overfit a small dataset (8 images).

```bash
python train_experiment_0_overfit.py
```

This script will:
- Load 8 images from the dataset
- Train for up to 100 epochs with early stopping
- Save visualizations to `experiment_0_outputs/`
- Stop when Loss < 0.02 AND Masked Accuracy > 99%

### Experiment 1: Fine-tuning Pretrained Model
Fine-tunes the converted BusterNet checkpoint on the full dataset.

```bash
python train_busternet.py --experiment A --epochs 50 --batch-size 8
```

Options:
- `--experiment A`: Fine-tune pretrained model (Experiment 1)
- `--experiment B`: Stage-wise training from scratch (Experiment 2)
- `--epochs`: Number of training epochs
- `--batch-size`: Batch size for training
- `--lr`: Learning rate (default: 1e-4)
- `--pretrained-path`: Path to pretrained weights (default: busternet_converted.pth)
- `--save-dir`: Directory to save checkpoints and predictions
- `--save-freq`: Save checkpoint every N epochs

### Experiment 2: Stage-wise Training (Original BusterNet Paper)
Implements the exact four-phase training procedure from the original BusterNet paper:

**Phase 1: Train ManiDet only**
```bash
python train_busternet.py --phase manidet --epochs 100
```
- Trains only the ManiDet branch (manipulation detection)
- Uses Binary Cross Entropy loss
- Learning rate: 1e-2 with validation-based reduction
- Saves: `manidet_best.pth`

**Phase 2: Train SimiDet only**
```bash
python train_busternet.py --phase simidet --epochs 100
```
- Trains only the SimiDet branch (similarity detection)
- Uses Binary Cross Entropy loss
- Learning rate: 1e-2 with validation-based reduction
- Saves: `simidet_best.pth`

**Phase 3: Train Fusion only**
```bash
python train_busternet.py --phase fusion --epochs 100
```
- Loads pretrained ManiDet and SimiDet weights
- Trains only the Fusion module and prediction layer
- Uses Categorical Cross Entropy loss (3-class)
- Learning rate: 1e-2 with validation-based reduction
- Saves: `fusion_best.pth`

**Phase 4: End-to-end fine-tuning**
```bash
python train_busternet.py --phase finetune --epochs 50
```
- Loads the fused model from Phase 3
- Unfreezes the entire network
- Uses Categorical Cross Entropy loss (3-class)
- Learning rate: 1e-5 (1000× reduction from phase 3)
- Saves: `busternet_final.pth`

**Run all phases sequentially:**
```bash
python train_busternet.py --phase all --epochs 100
```
This will automatically run all four phases in order, using the checkpoints from previous phases.

## Checkpointing and Resuming

Each phase saves its own checkpoint:
- `manidet_best.pth` - Best ManiDet model from Phase 1
- `simidet_best.pth` - Best SimiDet model from Phase 2
- `fusion_best.pth` - Best Fusion model from Phase 3
- `busternet_final.pth` - Best final model from Phase 4

Each checkpoint contains:
- model state_dict
- optimizer state_dict
- epoch
- best validation metric

To resume training from a checkpoint, simply ensure the checkpoint file exists in the save directory and run the training command again.

## Inference

Run inference on single images or datasets:

```bash
# Single image inference
python single_image_inference.py --image path/to/image.jpg --model path/to/checkpoint.pth

# Simple single image inference
python single_image_inference_simple.py --image path/to/image.jpg --model path/to/checkpoint.pth
```

## Expected Outputs

During training, you will see:
- Console output with loss and accuracy metrics
- Periodic checkpoint saves in the specified save directory
- Prediction visualizations (input, ground truth, prediction) saved periodically (in Experiment 0)

## Troubleshooting

### CUDA Out of Memory
- Reduce batch size using `--batch-size`
- The models are designed to work with batch size >= 1

### Missing Dataset Files
- Ensure the dataset is correctly placed in `coco_subset/`
- Verify the CSV files exist and contain correct paths
- Check that image and mask directories match the paths in the CSV files

### Module Import Errors
- Ensure all Python files are in the same directory
- Verify you installed the requirements: `pip install -r requirements.txt`

## References

This implementation follows the original BusterNet architecture for image forgery detection as described in the paper.
For more details, refer to the original paper and implementation.